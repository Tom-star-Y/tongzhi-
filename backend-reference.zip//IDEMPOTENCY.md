# 幂等性设计详解

## 核心概念

**幂等性（Idempotency）**：对于同一个请求，无论执行多少次，结果都应该相同，且不会产生副作用。

在告警通知系统中，幂等性确保：
- **同一告警 + 同一渠道 = 只发送一次通知**
- 即使系统重启、重试、网络抖动，也不会重复发送

---

## 实现策略

### 1. 唯一标识生成

```typescript
// 通知记录 ID = SHA256(alert_id + channel_type + channel_target)
function generateNotificationId(alertId: string, channel: NotificationChannel): string {
  const channelKey = `${channel.type}:${channel.target}`;
  return crypto
    .createHash("sha256")
    .update(`${alertId}:${channelKey}`)
    .digest("hex");
}
```

**示例**：
- Alert ID: `alert_20251114_143522_001`
- Channel: `email:ops@company.com`
- Notification ID: `a3f2e1d...` （固定值）

### 2. 数据库约束

```sql
CREATE TABLE notifications (
    id VARCHAR(64) PRIMARY KEY,  -- 唯一通知 ID
    alert_id VARCHAR(64) NOT NULL,
    channel_type VARCHAR(20) NOT NULL,
    channel_target VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    retry_count INT DEFAULT 0,
    last_attempt_at TIMESTAMP,
    sent_at TIMESTAMP,
    error TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    
    -- 防止重复插入
    UNIQUE (alert_id, channel_type, channel_target)
);

CREATE INDEX idx_notifications_status ON notifications(status);
CREATE INDEX idx_notifications_alert_id ON notifications(alert_id);
```

**关键点**：
- `PRIMARY KEY (id)` 确保唯一性
- `UNIQUE (alert_id, channel_type, channel_target)` 防止重复
- `INSERT ... ON CONFLICT DO NOTHING` （PostgreSQL）

### 3. 插入逻辑（幂等）

```typescript
async getOrCreate(alertId: string, channel: NotificationChannel): Promise<NotificationRecord> {
  const id = generateNotificationId(alertId, channel);

  // 先查询
  const existing = await db.query(
    "SELECT * FROM notifications WHERE id = ?",
    [id]
  );
  
  if (existing.length > 0) {
    return existing[0]; // 已存在，直接返回
  }

  // 不存在则插入（使用 ON CONFLICT 防止并发重复）
  await db.query(
    `INSERT INTO notifications (id, alert_id, channel_type, channel_target, status)
     VALUES (?, ?, ?, ?, 'pending')
     ON CONFLICT (id) DO NOTHING`,
    [id, alertId, channel.type, channel.target]
  );

  // 再次查询（处理并发插入情况）
  return await db.query("SELECT * FROM notifications WHERE id = ?", [id]);
}
```

### 4. 发送逻辑（幂等检查）

```typescript
async sendNotification(alert: Alert, channel: NotificationChannel): Promise<void> {
  const record = await this.repo.getOrCreate(alert.id, channel);

  // ✓ 幂等检查：如果已发送，直接返回
  if (record.status === "sent") {
    console.log(`[Notification] Already sent: ${record.id}`);
    return;
  }

  // 执行发送...
  try {
    await this.actualSend(alert, channel);
    await this.repo.updateStatus(record.id, "sent");
  } catch (error) {
    await this.repo.updateStatus(record.id, "failed", error.message);
  }
}
```

---

## 场景覆盖

### 场景 1：正常发送
```
1. 创建告警 alert_001
2. 发送到 email:ops@company.com
3. 生成 notification_id = hash(alert_001 + email:ops@...)
4. 插入数据库，status = pending
5. 发送成功，更新 status = sent
```

### 场景 2：重复调用（幂等）
```
1. 同一告警 alert_001
2. 再次发送到 email:ops@company.com
3. 生成相同的 notification_id
4. 查询数据库，发现 status = sent
5. ✓ 跳过发送，直接返回
```

### 场景 3：并发调用（竞态条件）
```
Thread A: getOrCreate(alert_001, email) -> 查询（不存在）-> 插入
Thread B: getOrCreate(alert_001, email) -> 查询（不存在）-> 插入

数据库处理：
- ON CONFLICT (id) DO NOTHING
- 只有一个插入成功，另一个被忽略
- 两个线程都查询到同一条记录 ✓
```

### 场景 4：网络重试
```
1. 发送邮件，SMTP 超时
2. 系统重试（3 次）
3. 每次重试都检查 status
4. 如果某次成功，status = sent
5. 后续重试看到 status = sent，跳过 ✓
```

### 场景 5：系统重启
```
1. 发送到一半，服务重启
2. 重启后重新处理告警
3. 查询数据库，发现 notification 已存在
4. 根据 status 决定是否继续发送 ✓
```

---

## 重试策略（指数退避）

```typescript
const maxRetries = 3;
const baseDelayMs = 1000; // 1 秒

async function sendWithRetry(record: NotificationRecord, alert: Alert, channel: NotificationChannel) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      await actualSend(alert, channel);
      await updateStatus(record.id, "sent");
      return; // 成功
    } catch (error) {
      console.error(`Attempt ${attempt + 1} failed:`, error);
      
      if (attempt < maxRetries - 1) {
        const delayMs = baseDelayMs * Math.pow(2, attempt); // 1s, 2s, 4s
        await sleep(delayMs);
      } else {
        await updateStatus(record.id, "failed", error.message);
        throw error;
      }
    }
  }
}
```

**延迟时间**：
- 第 1 次重试：1 秒
- 第 2 次重试：2 秒
- 第 3 次重试：4 秒
- 总共最多 3 次

---

## 数据一致性

### 问题：发送成功但状态更新失败
```
1. 邮件发送成功
2. 准备更新 status = sent
3. 数据库连接断开 ❌
4. 状态仍然是 pending
```

**解决方案**：
- **方案 A**：先更新状态，再发送（不推荐）
  - 问题：如果发送失败，状态已标记为 sent，无法重试
  
- **方案 B**：使用事务 + 幂等发送接口
  - SMTP/Teams Webhook 通常不支持事务
  
- **方案 C**：定期扫描 + 外部幂等 key（推荐）
  ```typescript
  // 邮件服务支持幂等 key（如 AWS SES 的 MessageId）
  await sendEmail({
    to: "ops@company.com",
    subject: "...",
    body: "...",
    messageId: record.id, // 幂等 key
  });
  
  // 即使重复调用，邮件服务也只发送一次
  ```

### 定期扫描（兜底机制）
```typescript
// 每 5 分钟扫描一次 pending 超过 10 分钟的记录
setInterval(async () => {
  const stuckRecords = await db.query(
    `SELECT * FROM notifications 
     WHERE status = 'pending' 
     AND last_attempt_at < NOW() - INTERVAL '10 minutes'
     AND retry_count < 3`
  );

  for (const record of stuckRecords) {
    await resendNotification(record);
  }
}, 5 * 60 * 1000);
```

---

## 测试用例

### 单元测试
```typescript
describe("Notification Idempotency", () => {
  it("should generate same ID for same alert + channel", () => {
    const id1 = generateNotificationId("alert_001", { type: "email", target: "test@example.com" });
    const id2 = generateNotificationId("alert_001", { type: "email", target: "test@example.com" });
    expect(id1).toBe(id2);
  });

  it("should not send duplicate notifications", async () => {
    const alert = createTestAlert();
    const channel = { type: "email", target: "test@example.com" };

    await service.sendNotification(alert, channel);
    await service.sendNotification(alert, channel); // 重复调用

    const record = await repo.findById(generateNotificationId(alert.id, channel));
    expect(record.status).toBe("sent");
    expect(mockEmailService.sendCount).toBe(1); // ✓ 只发送一次
  });
});
```

### 集成测试
```typescript
describe("Concurrent Notifications", () => {
  it("should handle concurrent sends correctly", async () => {
    const alert = createTestAlert();
    const channel = { type: "email", target: "test@example.com" };

    // 模拟并发
    await Promise.all([
      service.sendNotification(alert, channel),
      service.sendNotification(alert, channel),
      service.sendNotification(alert, channel),
    ]);

    const record = await repo.findById(generateNotificationId(alert.id, channel));
    expect(record.status).toBe("sent");
    expect(mockEmailService.sendCount).toBe(1); // ✓ 只发送一次
  });
});
```

---

## 监控与告警

### 关键指标
```typescript
// 1. 发送成功率
const successRate = (sentCount / totalCount) * 100;

// 2. 平均重试次数
const avgRetries = totalRetries / totalAlerts;

// 3. 失败告警（重试 3 次后仍失败）
const criticalFailures = await db.query(
  "SELECT COUNT(*) FROM notifications WHERE status = 'failed' AND retry_count >= 3"
);

// 4. Pending 超时（超过 10 分钟仍未发送）
const stuckNotifications = await db.query(
  `SELECT COUNT(*) FROM notifications 
   WHERE status = 'pending' AND created_at < NOW() - INTERVAL '10 minutes'`
);
```

### 告警规则
```
- 发送成功率 < 95%：触发告警
- Pending 超时数量 > 10：触发告警
- 单个告警重试次数 >= 3：触发告警
```

---

## 总结

| 机制 | 作用 | 实现方式 |
|------|------|----------|
| **唯一 ID** | 防止重复记录 | SHA256(alert_id + channel) |
| **数据库约束** | 防止并发插入 | PRIMARY KEY + UNIQUE |
| **状态检查** | 防止重复发送 | `if (status === "sent") return` |
| **重试机制** | 处理临时失败 | 指数退避（1s, 2s, 4s） |
| **定期扫描** | 兜底处理卡住的任务 | 每 5 分钟扫描 pending > 10min |
| **外部幂等** | 服务端防重 | MessageId / RequestId |

**核心思想**：
- **一次记录 = 一次发送**
- **同一 ID = 同一结果**
- **多次调用 = 一次执行**
