/**
 * 推送服务实现参考（Go）
 * 
 * 核心功能：
 * 1. 多渠道推送（Email/Teams/Webhook）
 * 2. 幂等性保证（基于 alert_id + notification_id）
 * 3. 重试机制（指数退避）
 * 4. 失败告警
 */

package notification

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"gopkg.in/gomail.v2"
)

// ========== 数据模型 ==========

type Alert struct {
	ID          string                 `json:"id"`
	RuleID      string                 `json:"rule_id"`
	RuleName    string                 `json:"rule_name"`
	Severity    string                 `json:"severity"` // info, warning, critical
	TriggeredAt string                 `json:"triggered_at"`
	WindowStart string                 `json:"window_start"`
	WindowEnd   string                 `json:"window_end"`
	Count       int                    `json:"count"`
	CallIDs     []string               `json:"call_ids"`
	Metadata    map[string]interface{} `json:"metadata"`
}

type NotificationChannel struct {
	Type       string `json:"type"`        // email, teams, webhook
	Target     string `json:"target"`      // email address / webhook URL
	TemplateID string `json:"template_id"` // optional
}

type NotificationRecord struct {
	ID            string              `json:"id"`
	AlertID       string              `json:"alert_id"`
	Channel       NotificationChannel `json:"channel"`
	Status        string              `json:"status"` // pending, sent, failed
	RetryCount    int                 `json:"retry_count"`
	LastAttemptAt *time.Time          `json:"last_attempt_at"`
	SentAt        *time.Time          `json:"sent_at"`
	Error         string              `json:"error"`
}

// ========== 幂等性设计 ==========

// GenerateNotificationID 生成通知记录 ID（确保幂等）
// 同一告警 + 同一渠道 = 同一通知 ID
func GenerateNotificationID(alertID string, channel NotificationChannel) string {
	channelKey := fmt.Sprintf("%s:%s", channel.Type, channel.Target)
	hash := sha256.Sum256([]byte(alertID + ":" + channelKey))
	return hex.EncodeToString(hash[:])
}

// ========== 数据库操作（伪码） ==========

type NotificationRepository struct {
	// db *sql.DB
}

// GetOrCreate 获取或创建通知记录（实现幂等）
func (r *NotificationRepository) GetOrCreate(ctx context.Context, alertID string, channel NotificationChannel) (*NotificationRecord, error) {
	id := GenerateNotificationID(alertID, channel)

	// 尝试从数据库查询
	existing, err := r.FindByID(ctx, id)
	if err == nil && existing != nil {
		return existing, nil
	}

	// 不存在则创建新记录
	record := &NotificationRecord{
		ID:         id,
		AlertID:    alertID,
		Channel:    channel,
		Status:     "pending",
		RetryCount: 0,
	}

	err = r.Insert(ctx, record)
	if err != nil {
		return nil, err
	}

	return record, nil
}

func (r *NotificationRepository) FindByID(ctx context.Context, id string) (*NotificationRecord, error) {
	// SELECT * FROM notifications WHERE id = ?
	// 实现略
	return nil, fmt.Errorf("not implemented")
}

func (r *NotificationRepository) Insert(ctx context.Context, record *NotificationRecord) error {
	// INSERT INTO notifications (id, alert_id, ...) VALUES (?, ?, ...)
	// ON CONFLICT (id) DO NOTHING （PostgreSQL）
	// 实现略
	return nil
}

func (r *NotificationRepository) UpdateStatus(ctx context.Context, id string, status string, errorMsg string) error {
	// UPDATE notifications SET status = ?, error = ?, sent_at = NOW()
	// WHERE id = ?
	// 实现略
	return nil
}

func (r *NotificationRepository) IncrementRetry(ctx context.Context, id string) error {
	// UPDATE notifications SET retry_count = retry_count + 1,
	// last_attempt_at = NOW() WHERE id = ?
	// 实现略
	return nil
}

// ========== 推送服务核心 ==========

type NotificationService struct {
	repo         *NotificationRepository
	smtpHost     string
	smtpPort     int
	smtpUser     string
	smtpPassword string
	smtpFrom     string
}

func NewNotificationService(smtpHost string, smtpPort int, smtpUser, smtpPassword, smtpFrom string) *NotificationService {
	return &NotificationService{
		repo:         &NotificationRepository{},
		smtpHost:     smtpHost,
		smtpPort:     smtpPort,
		smtpUser:     smtpUser,
		smtpPassword: smtpPassword,
		smtpFrom:     smtpFrom,
	}
}

// SendNotification 发送通知（入口函数）
// 幂等：同一 alertID + channel 只会发送一次
func (s *NotificationService) SendNotification(ctx context.Context, alert *Alert, channel NotificationChannel, template string) error {
	// 1. 获取或创建通知记录（实现幂等）
	record, err := s.repo.GetOrCreate(ctx, alert.ID, channel)
	if err != nil {
		return fmt.Errorf("failed to get or create notification record: %w", err)
	}

	// 2. 如果已发送，直接返回（幂等保证）
	if record.Status == "sent" {
		fmt.Printf("[Notification] Already sent: %s\n", record.ID)
		return nil
	}

	// 3. 检查重试次数（避免无限重试）
	maxRetries := 3
	if record.RetryCount >= maxRetries {
		fmt.Printf("[Notification] Max retries exceeded: %s\n", record.ID)
		return s.repo.UpdateStatus(ctx, record.ID, "failed", "Max retries exceeded")
	}

	// 4. 执行发送
	err = s.repo.IncrementRetry(ctx, record.ID)
	if err != nil {
		return err
	}

	var sendErr error
	switch channel.Type {
	case "email":
		sendErr = s.sendEmail(alert, channel.Target, template)
	case "teams":
		sendErr = s.sendTeams(alert, channel.Target, template)
	case "webhook":
		sendErr = s.sendWebhook(alert, channel.Target)
	default:
		sendErr = fmt.Errorf("unknown channel type: %s", channel.Type)
	}

	if sendErr != nil {
		// 发送失败，记录错误
		fmt.Printf("[Notification] Failed to send: %s, error: %v\n", record.ID, sendErr)
		s.repo.UpdateStatus(ctx, record.ID, "failed", sendErr.Error())

		// 5. 重试逻辑（指数退避）
		if record.RetryCount < maxRetries {
			delaySeconds := 1 << record.RetryCount // 1s, 2s, 4s
			time.AfterFunc(time.Duration(delaySeconds)*time.Second, func() {
				s.SendNotification(context.Background(), alert, channel, template)
			})
		}
		return sendErr
	}

	// 6. 标记为已发送
	err = s.repo.UpdateStatus(ctx, record.ID, "sent", "")
	if err != nil {
		return err
	}

	fmt.Printf("[Notification] Sent successfully: %s\n", record.ID)
	return nil
}

// SendBatch 批量发送（对同一告警的多个渠道）
func (s *NotificationService) SendBatch(ctx context.Context, alert *Alert, channels []NotificationChannel, template string) error {
	// 并发发送（每个渠道独立幂等）
	for _, channel := range channels {
		go s.SendNotification(ctx, alert, channel, template)
	}
	return nil
}

// ========== 各渠道实现 ==========

func (s *NotificationService) sendEmail(alert *Alert, to string, templateBody string) error {
	subject := fmt.Sprintf("【告警】%s 触发", alert.RuleName)
	if templateBody == "" {
		templateBody = s.getDefaultEmailTemplate()
	}
	body := s.renderTemplate(templateBody, alert)

	m := gomail.NewMessage()
	m.SetHeader("From", s.smtpFrom)
	m.SetHeader("To", to)
	m.SetHeader("Subject", subject)
	m.SetBody("text/plain", body)

	d := gomail.NewDialer(s.smtpHost, s.smtpPort, s.smtpUser, s.smtpPassword)
	return d.DialAndSend(m)
}

func (s *NotificationService) sendTeams(alert *Alert, webhookURL string, templateBody string) error {
	if templateBody == "" {
		templateBody = s.getDefaultTeamsTemplate()
	}
	card := s.renderTemplate(templateBody, alert)

	resp, err := http.Post(webhookURL, "application/json", bytes.NewBufferString(card))
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return fmt.Errorf("teams webhook returned status %d", resp.StatusCode)
	}
	return nil
}

func (s *NotificationService) sendWebhook(alert *Alert, url string) error {
	jsonData, err := json.Marshal(alert)
	if err != nil {
		return err
	}

	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		return fmt.Errorf("webhook returned status %d", resp.StatusCode)
	}
	return nil
}

// ========== 模板渲染 ==========

func (s *NotificationService) renderTemplate(template string, alert *Alert) string {
	callLinks := ""
	for _, id := range alert.CallIDs {
		callLinks += "- " + id + "\n"
	}

	variables := map[string]string{
		"rule_name":      alert.RuleName,
		"window_start":   alert.WindowStart,
		"window_end":     alert.WindowEnd,
		"count":          fmt.Sprintf("%d", alert.Count),
		"severity":       alert.Severity,
		"call_links":     callLinks,
		"dashboard_link": fmt.Sprintf("https://dashboard.example.com/alerts/%s", alert.ID),
	}

	result := template
	for key, value := range variables {
		result = strings.ReplaceAll(result, "{"+key+"}", value)
	}
	return result
}

func (s *NotificationService) getDefaultEmailTemplate() string {
	return `您好，

规则 "{rule_name}" 在 {window_start} 至 {window_end} 期间触发了告警。

触发次数: {count}
严重程度: {severity}

示例通话ID:
{call_links}

请及时查看并处理：{dashboard_link}

---
此邮件由系统自动发送，请勿回复。`
}

func (s *NotificationService) getDefaultTeamsTemplate() string {
	return `{
  "@type": "MessageCard",
  "@context": "https://schema.org/extensions",
  "summary": "告警通知",
  "themeColor": "FF0000",
  "title": "告警: {rule_name}",
  "sections": [
    {
      "activityTitle": "规则触发详情",
      "facts": [
        { "name": "时间窗口", "value": "{window_start} ~ {window_end}" },
        { "name": "触发次数", "value": "{count}" },
        { "name": "严重程度", "value": "{severity}" }
      ]
    }
  ],
  "potentialAction": [
    {
      "@type": "OpenUri",
      "name": "查看详情",
      "targets": [{ "os": "default", "uri": "{dashboard_link}" }]
    }
  ]
}`
}

// ========== 使用示例 ==========

func ExampleUsage() {
	service := NewNotificationService(
		"smtp.example.com",
		587,
		"user@example.com",
		"password",
		"alerts@company.com",
	)

	alert := &Alert{
		ID:          "alert_20251114_143522_001",
		RuleID:      "rule_001",
		RuleName:    "高频支付失败",
		Severity:    "critical",
		TriggeredAt: "2025-11-14 14:35:22",
		WindowStart: "2025-11-14 14:00:00",
		WindowEnd:   "2025-11-14 14:30:00",
		Count:       8,
		CallIDs:     []string{"call_001", "call_002", "call_003"},
		Metadata:    map[string]interface{}{},
	}

	channels := []NotificationChannel{
		{Type: "email", Target: "ops@company.com"},
		{Type: "teams", Target: "https://outlook.office.com/webhook/..."},
	}

	ctx := context.Background()

	// 批量发送（幂等保证：同一告警+渠道只发一次）
	service.SendBatch(ctx, alert, channels, "")

	// 重复调用不会重复发送
	service.SendBatch(ctx, alert, channels, "") // ✓ 幂等，不会重复发送
}
