# 通话标签驱动的告警通知系统 - 后端实现参考

## 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│                          前端（React）                            │
│  - 规则配置界面（RuleCreation）                                    │
│  - 通知模板管理（NotificationTemplates）                           │
│  - 告警列表展示（AlertList）                                       │
└──────────────────────────┬──────────────────────────────────────┘
                           │ REST API
┌──────────────────────────▼──────────────────────────────────────┐
│                     API Gateway / 后端服务                        │
│  - 规则管理 API（CRUD）                                           │
│  - 模板管理 API                                                   │
│  - 告警查询 API                                                   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
┌───────▼────────┐  ┌──────▼──────┐  ┌────────▼────────┐
│  标签入库服务   │  │ 规则引擎服务 │  │  推送服务       │
│                │  │              │  │ (幂等设计)       │
│ - 接收标签事件 │  │ - 流式聚合   │  │ - Email         │
│ - 写入数据库   │  │ - 规则匹配   │  │ - Teams         │
│ - 发送到消息队列│  │ - 触发告警   │  │ - Webhook       │
└────────────────┘  └──────────────┘  └─────────────────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│                      数据存储层                                   │
│  - PostgreSQL（规则、模板、通知记录）                              │
│  - Redis（滑动窗口缓存、冷却期状态）                               │
│  - Kafka / Redis Streams（标签事件流）                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 核心组件

### 1. 标签入库服务（Tag Ingestion Service）

**功能**：接收通话后端产生的标签事件

```typescript
// POST /api/v1/tags
{
  "call_id": "call_20251114_143000",
  "tag_key": "支付结果",
  "tag_type": "enum",
  "tag_value": "503",
  "confidence": 0.92,
  "created_at": "2025-11-14T14:30:00Z",
  "metadata": {
    "agent_id": "agent_001",
    "phone": "138****1234"
  }
}
```

**处理流程**：
1. 验证标签格式
2. 写入数据库（tags 表）
3. 发送到消息队列（Kafka / Redis Streams）

**数据库表**：
```sql
CREATE TABLE tags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id VARCHAR(64) NOT NULL,
    tag_key VARCHAR(128) NOT NULL,
    tag_type VARCHAR(20) NOT NULL, -- text, time, number, enum, boolean
    tag_value TEXT NOT NULL,
    confidence DECIMAL(3, 2),
    created_at TIMESTAMP NOT NULL,
    metadata JSONB,
    
    INDEX idx_tags_call_id (call_id),
    INDEX idx_tags_tag_key (tag_key),
    INDEX idx_tags_created_at (created_at)
);
```

---

### 2. 规则引擎服务（Rule Engine Service）

**功能**：实时监听标签流，匹配规则并触发告警

**技术选型**：
- **流处理框架**：Kafka Streams / Flink / Redis Streams
- **窗口聚合**：Sliding Window（滑动窗口）
- **状态存储**：Redis（窗口计数、冷却期）

**核心逻辑**：

```typescript
// 伪代码：流式处理
tagStream
  .groupBy(tag => tag.tag_key) // 按标签类型分组
  .window(SlidingWindow.of(Duration.ofMinutes(30))) // 30 分钟滑动窗口
  .aggregate((windowTags) => {
    // 对每个窗口内的标签进行聚合
    const rules = getRulesForTagKey(windowTags[0].tag_key);
    
    for (const rule of rules) {
      if (matchesRule(windowTags, rule)) {
        // 检查冷却期
        if (!isInCooldown(rule.id)) {
          triggerAlert(rule, windowTags);
          setCooldown(rule.id, rule.cooldown_seconds);
        }
      }
    }
  });
```

**规则匹配示例**：

```typescript
function matchesRule(tags: Tag[], rule: Rule): boolean {
  // 1. 过滤条件
  let filteredTags = tags.filter(tag => {
    if (!matchesFilters(tag, rule.filters)) return false;
    return true;
  });

  // 2. 判断条件
  filteredTags = filteredTags.filter(tag => {
    switch (rule.tag_type) {
      case "enum":
        return rule.values.includes(tag.tag_value);
      case "number":
        return evaluateNumberCondition(tag.tag_value, rule.operator, rule.values);
      case "boolean":
        return tag.tag_value === rule.values[0];
      default:
        return true;
    }
  });

  // 3. 阈值检查
  return filteredTags.length >= rule.threshold;
}
```

**冷却期实现**（Redis）：

```typescript
async function isInCooldown(ruleId: string): Promise<boolean> {
  const key = `cooldown:${ruleId}`;
  const exists = await redis.exists(key);
  return exists === 1;
}

async function setCooldown(ruleId: string, seconds: number): Promise<void> {
  const key = `cooldown:${ruleId}`;
  await redis.setex(key, seconds, "1");
}
```

---

### 3. 推送服务（Notification Service）

**功能**：多渠道推送，幂等设计

详见 `notification-service.ts` 和 `notification-service.go`

**关键特性**：
- ✅ 幂等性：同一告警 + 同一渠道只发送一次
- ✅ 重试机制：指数退避（1s, 2s, 4s）
- ✅ 失败告警：重试 3 次后仍失败则记录并告警
- ✅ 模板渲染：支持变量替换

**数据库表**：
```sql
CREATE TABLE notifications (
    id VARCHAR(64) PRIMARY KEY,
    alert_id VARCHAR(64) NOT NULL,
    channel_type VARCHAR(20) NOT NULL,
    channel_target VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    retry_count INT DEFAULT 0,
    last_attempt_at TIMESTAMP,
    sent_at TIMESTAMP,
    error TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE (alert_id, channel_type, channel_target),
    INDEX idx_notifications_status (status),
    INDEX idx_notifications_alert_id (alert_id)
);
```

---

## API 设计

### 规则管理

#### 1. 创建规则
```http
POST /api/v1/alert-rules
Content-Type: application/json

{
  "name": "高频支付失败",
  "tag_key": "支付结果",
  "tag_type": "enum",
  "condition": {
    "operator": "IN",
    "values": ["503", "网关超时"]
  },
  "window_minutes": 30,
  "threshold": 5,
  "filters": {
    "customer_tier": ["VIP"],
    "region": null
  },
  "cooldown_seconds": 1200,
  "notifications": [
    { "type": "email", "target": "ops@company.com" },
    { "type": "teams", "target": "https://..." }
  ],
  "severity": "critical",
  "enabled": true
}
```

**响应**：
```json
{
  "id": "rule_001",
  "created_at": "2025-11-14T14:35:22Z",
  "status": "active"
}
```

#### 2. 查询规则列表
```http
GET /api/v1/alert-rules?enabled=true&severity=critical
```

#### 3. 更新规则
```http
PUT /api/v1/alert-rules/rule_001
```

#### 4. 启用/禁用规则
```http
PATCH /api/v1/alert-rules/rule_001/toggle
```

---

### 告警查询

#### 1. 查询告警列表
```http
GET /api/v1/alerts?from=2025-11-14T00:00:00Z&to=2025-11-14T23:59:59Z&rule_id=rule_001&severity=critical
```

**响应**：
```json
{
  "alerts": [
    {
      "id": "alert_001",
      "rule_id": "rule_001",
      "rule_name": "高频支付失败",
      "severity": "critical",
      "triggered_at": "2025-11-14T14:35:22Z",
      "window_start": "2025-11-14T14:00:00Z",
      "window_end": "2025-11-14T14:30:00Z",
      "count": 8,
      "call_ids": ["call_001", "call_002", "..."],
      "read": false
    }
  ],
  "total": 42,
  "page": 1
}
```

#### 2. 导出 CSV
```http
GET /api/v1/alerts/export?from=...&to=...
```

---

### 模板管理

#### 1. 创建模板
```http
POST /api/v1/notification-templates

{
  "name": "默认邮件模板",
  "type": "email",
  "subject": "【告警】{rule_name} 触发",
  "body": "...",
  "format": "plain"
}
```

#### 2. 查询模板列表
```http
GET /api/v1/notification-templates?type=email
```

---

## 部署建议

### Docker Compose 示例

```yaml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: alert_system
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7
    ports:
      - "6379:6379"

  kafka:
    image: confluentinc/cp-kafka:latest
    environment:
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092
    ports:
      - "9092:9092"

  tag-ingestion:
    build: ./services/tag-ingestion
    environment:
      DATABASE_URL: postgres://admin:password@postgres:5432/alert_system
      KAFKA_BROKERS: kafka:9092
    ports:
      - "3001:3000"

  rule-engine:
    build: ./services/rule-engine
    environment:
      DATABASE_URL: postgres://admin:password@postgres:5432/alert_system
      REDIS_URL: redis://redis:6379
      KAFKA_BROKERS: kafka:9092

  notification-service:
    build: ./services/notification
    environment:
      DATABASE_URL: postgres://admin:password@postgres:5432/alert_system
      SMTP_HOST: smtp.example.com
      SMTP_PORT: 587
      SMTP_USER: alerts@company.com
      SMTP_PASSWORD: password

  api-gateway:
    build: ./services/api
    environment:
      DATABASE_URL: postgres://admin:password@postgres:5432/alert_system
    ports:
      - "3000:3000"

volumes:
  postgres_data:
```

---

## 监控与告警

### 关键指标（Prometheus）

```yaml
# 规则引擎
- rule_evaluations_total # 规则评估次数
- rule_matches_total # 规则匹配次数
- alert_triggers_total # 告警触发次数

# 推送服务
- notification_sends_total # 发送总数
- notification_failures_total # 失败总数
- notification_retry_count # 重试次数

# 延迟
- tag_to_alert_latency_seconds # 标签到告警的延迟
- notification_send_latency_seconds # 推送延迟
```

### Grafana 面板

1. **告警总览**：触发次数、严重度分布
2. **规则性能**：评估延迟、匹配率
3. **推送状态**：成功率、重试率、失败详情
4. **系统健康**：消息队列堆积、数据库连接数

---

## 测试策略

### 单元测试
- 规则匹配逻辑
- 模板渲染
- 幂等性检查

### 集成测试
- 端到端流程：标签 → 规则匹配 → 告警触发 → 推送
- 并发场景：多个标签同时到达
- 故障恢复：数据库重启、网络中断

### 压力测试
- 每秒 1000 个标签事件
- 100 个活跃规则
- 50 个并发告警

---

## 安全与合规

### 数据脱敏
```typescript
function sanitizePhoneNumber(phone: string): string {
  return phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2");
}
```

### 权限控制
- 管理员：创建/编辑规则、查看所有告警
- 主管：查看告警、标记已读
- 普通客服：查看关联通话

### 审计日志
```sql
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY,
    user_id VARCHAR(64),
    action VARCHAR(64), -- create_rule, edit_rule, delete_rule
    resource_id VARCHAR(64),
    changes JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## FAQ

### Q1: 如何防止告警风暴？
**A**: 
- 冷却期机制（默认 20 分钟）
- 合并相似告警（同一规则的多次触发）
- 告警分级（info 不推送，只记录）

### Q2: 如何确保不遗漏告警？
**A**:
- 双写机制（消息队列 + 数据库）
- 定期扫描兜底（每 5 分钟）
- 监控规则引擎延迟

### Q3: 如何支持复杂规则（AND/OR）？
**A**:
```json
{
  "conditions": {
    "operator": "AND",
    "rules": [
      { "tag_key": "支付结果", "operator": "IN", "values": ["503"] },
      { "tag_key": "地区", "operator": "=", "values": ["上海"] }
    ]
  }
}
```

### Q4: 如何处理大量历史告警？
**A**:
- 归档策略（90 天后移到冷存储）
- 分页查询（每页 50 条）
- 索引优化（created_at, rule_id）

---

## 参考文档

- [幂等性设计详解](./IDEMPOTENCY.md)
- [TypeScript 实现](./notification-service.ts)
- [Go 实现](./notification-service.go)

---

## 贡献指南

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/xxx`)
3. 提交代码 (`git commit -m 'Add xxx'`)
4. 推送到分支 (`git push origin feature/xxx`)
5. 创建 Pull Request

---

## 许可证

MIT License
