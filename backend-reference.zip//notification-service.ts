/**
 * 推送服务实现参考（TypeScript/Node.js）
 * 
 * 核心功能：
 * 1. 多渠道推送（Email/Teams/Webhook）
 * 2. 幂等性保证（基于 alert_id + notification_id）
 * 3. 重试机制（指数退避）
 * 4. 失败告警
 */

import crypto from "crypto";
import nodemailer from "nodemailer";
import axios from "axios";

// ========== 数据模型 ==========

interface Alert {
  id: string; // 唯一告警 ID
  ruleId: string;
  ruleName: string;
  severity: "info" | "warning" | "critical";
  triggeredAt: string;
  windowStart: string;
  windowEnd: string;
  count: number;
  callIds: string[];
  metadata: Record<string, any>;
}

interface NotificationChannel {
  type: "email" | "teams" | "webhook";
  target: string; // email address / webhook URL
  templateId?: string;
}

interface NotificationRecord {
  id: string; // 通知记录唯一 ID（用于幂等）
  alertId: string;
  channel: NotificationChannel;
  status: "pending" | "sent" | "failed";
  retryCount: number;
  lastAttemptAt?: string;
  sentAt?: string;
  error?: string;
}

// ========== 幂等性设计 ==========

/**
 * 生成通知记录 ID（确保幂等）
 * 同一告警 + 同一渠道 = 同一通知 ID
 */
function generateNotificationId(alertId: string, channel: NotificationChannel): string {
  const channelKey = `${channel.type}:${channel.target}`;
  return crypto
    .createHash("sha256")
    .update(`${alertId}:${channelKey}`)
    .digest("hex");
}

// ========== 数据库操作（伪码） ==========

class NotificationRepository {
  /**
   * 获取或创建通知记录（实现幂等）
   */
  async getOrCreate(
    alertId: string,
    channel: NotificationChannel
  ): Promise<NotificationRecord> {
    const id = generateNotificationId(alertId, channel);

    // 尝试从数据库查询
    const existing = await this.findById(id);
    if (existing) {
      return existing;
    }

    // 不存在则创建新记录
    const record: NotificationRecord = {
      id,
      alertId,
      channel,
      status: "pending",
      retryCount: 0,
    };

    await this.insert(record);
    return record;
  }

  async findById(id: string): Promise<NotificationRecord | null> {
    // SELECT * FROM notifications WHERE id = ?
    // 实现略
    return null as any;
  }

  async insert(record: NotificationRecord): Promise<void> {
    // INSERT INTO notifications (id, alert_id, ...) VALUES (?, ?, ...)
    // ON CONFLICT (id) DO NOTHING （PostgreSQL）
    // 实现略
  }

  async updateStatus(
    id: string,
    status: "sent" | "failed",
    error?: string
  ): Promise<void> {
    // UPDATE notifications SET status = ?, error = ?, sent_at = NOW()
    // WHERE id = ?
    // 实现略
  }

  async incrementRetry(id: string): Promise<void> {
    // UPDATE notifications SET retry_count = retry_count + 1,
    // last_attempt_at = NOW() WHERE id = ?
    // 实现略
  }
}

// ========== 推送服务核心 ==========

class NotificationService {
  private repo = new NotificationRepository();
  private emailTransporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || "587"),
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  /**
   * 发送通知（入口函数）
   * 幂等：同一 alertId + channel 只会发送一次
   */
  async sendNotification(
    alert: Alert,
    channel: NotificationChannel,
    template?: string
  ): Promise<void> {
    // 1. 获取或创建通知记录（实现幂等）
    const record = await this.repo.getOrCreate(alert.id, channel);

    // 2. 如果已发送，直接返回（幂等保证）
    if (record.status === "sent") {
      console.log(`[Notification] Already sent: ${record.id}`);
      return;
    }

    // 3. 检查重试次数（避免无限重试）
    const maxRetries = 3;
    if (record.retryCount >= maxRetries) {
      console.error(`[Notification] Max retries exceeded: ${record.id}`);
      await this.repo.updateStatus(record.id, "failed", "Max retries exceeded");
      return;
    }

    // 4. 执行发送
    try {
      await this.repo.incrementRetry(record.id);

      switch (channel.type) {
        case "email":
          await this.sendEmail(alert, channel.target, template);
          break;
        case "teams":
          await this.sendTeams(alert, channel.target, template);
          break;
        case "webhook":
          await this.sendWebhook(alert, channel.target);
          break;
      }

      // 5. 标记为已发送
      await this.repo.updateStatus(record.id, "sent");
      console.log(`[Notification] Sent successfully: ${record.id}`);
    } catch (error: any) {
      console.error(`[Notification] Failed to send: ${record.id}`, error);
      await this.repo.updateStatus(record.id, "failed", error.message);

      // 6. 重试逻辑（指数退避）
      if (record.retryCount < maxRetries) {
        const delayMs = Math.pow(2, record.retryCount) * 1000; // 1s, 2s, 4s
        setTimeout(() => {
          this.sendNotification(alert, channel, template);
        }, delayMs);
      }
    }
  }

  /**
   * 批量发送（对同一告警的多个渠道）
   */
  async sendBatch(
    alert: Alert,
    channels: NotificationChannel[],
    template?: string
  ): Promise<void> {
    // 并发发送（每个渠道独立幂等）
    await Promise.all(
      channels.map((channel) => this.sendNotification(alert, channel, template))
    );
  }

  // ========== 各渠道实现 ==========

  private async sendEmail(
    alert: Alert,
    to: string,
    templateBody?: string
  ): Promise<void> {
    const subject = `【告警】${alert.ruleName} 触发`;
    const body = this.renderTemplate(templateBody || this.getDefaultEmailTemplate(), alert);

    await this.emailTransporter.sendMail({
      from: process.env.SMTP_FROM || "alerts@company.com",
      to,
      subject,
      text: body,
    });
  }

  private async sendTeams(
    alert: Alert,
    webhookUrl: string,
    templateBody?: string
  ): Promise<void> {
    const card = this.renderTemplate(
      templateBody || this.getDefaultTeamsTemplate(),
      alert
    );

    await axios.post(webhookUrl, JSON.parse(card), {
      headers: { "Content-Type": "application/json" },
      timeout: 10000,
    });
  }

  private async sendWebhook(alert: Alert, url: string): Promise<void> {
    await axios.post(url, alert, {
      headers: { "Content-Type": "application/json" },
      timeout: 10000,
    });
  }

  // ========== 模板渲染 ==========

  private renderTemplate(template: string, alert: Alert): string {
    const variables = {
      rule_name: alert.ruleName,
      window_start: alert.windowStart,
      window_end: alert.windowEnd,
      count: alert.count.toString(),
      severity: alert.severity,
      call_links: alert.callIds.map((id) => `- ${id}`).join("\n"),
      dashboard_link: `https://dashboard.example.com/alerts/${alert.id}`,
    };

    let result = template;
    Object.entries(variables).forEach(([key, value]) => {
      result = result.replaceAll(`{${key}}`, value);
    });
    return result;
  }

  private getDefaultEmailTemplate(): string {
    return `您好，

规则 "{rule_name}" 在 {window_start} 至 {window_end} 期间触发了告警。

触发次数: {count}
严重程度: {severity}

示例通话ID:
{call_links}

请及时查看并处理：{dashboard_link}

---
此邮件由系统自动发送，请勿回复。`;
  }

  private getDefaultTeamsTemplate(): string {
    return `{
  "@type": "MessageCard",
  "@context": "https://schema.org/extensions",
  "summary": "告警通知",
  "themeColor": "FF0000",
  "title": "告警: {rule_name}",
  "sections": [
    {
      "activityTitle": "规则触发详情",
      "facts": [
        { "name": "时间窗口", "value": "{window_start} ~ {window_end}" },
        { "name": "触发次数", "value": "{count}" },
        { "name": "严重程度", "value": "{severity}" }
      ]
    }
  ],
  "potentialAction": [
    {
      "@type": "OpenUri",
      "name": "查看详情",
      "targets": [{ "os": "default", "uri": "{dashboard_link}" }]
    }
  ]
}`;
  }
}

// ========== 使用示例 ==========

async function example() {
  const service = new NotificationService();

  const alert: Alert = {
    id: "alert_20251114_143522_001",
    ruleId: "rule_001",
    ruleName: "高频支付失败",
    severity: "critical",
    triggeredAt: "2025-11-14 14:35:22",
    windowStart: "2025-11-14 14:00:00",
    windowEnd: "2025-11-14 14:30:00",
    count: 8,
    callIds: ["call_001", "call_002", "call_003"],
    metadata: {},
  };

  const channels: NotificationChannel[] = [
    { type: "email", target: "ops@company.com" },
    { type: "teams", target: "https://outlook.office.com/webhook/..." },
  ];

  // 批量发送（幂等保证：同一告警+渠道只发一次）
  await service.sendBatch(alert, channels);

  // 重复调用不会重复发送
  await service.sendBatch(alert, channels); // ✓ 幂等，不会重复发送
}

export { NotificationService, NotificationChannel, Alert };
